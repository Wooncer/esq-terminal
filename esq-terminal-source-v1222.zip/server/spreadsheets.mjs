import XLSX from '../web/vendor/xlsx.full.min.cjs';
export function spreadsheetText(file,bytes){
 const limits={cells:20000,rows:5000,sheets:30,characters:240000};
 // Bound OOXML expansion before the parser allocates uncompressed worksheet XML.
 if(bytes[0]===0x50&&bytes[1]===0x4b){let expanded=0;const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);for(let i=0;i+46<bytes.length;i++)if(view.getUint32(i,true)===0x02014b50){expanded+=view.getUint32(i+24,true);if(expanded>40*1024*1024)throw Error('Распакованный Excel больше 40 МБ. Разделите книгу.');i+=45+view.getUint16(i+28,true)+view.getUint16(i+30,true)+view.getUint16(i+32,true);}}
 let book;try{book=XLSX.read(bytes,{type:'array',cellFormula:true,cellText:true,cellNF:true,cellHTML:false,bookVBA:false,cellDates:false});}catch{throw Error('Не удалось прочитать Excel. Проверьте, что файл не повреждён и не защищён паролем.');}
 if(book.SheetNames.length>limits.sheets)throw Error('В Excel больше 30 листов. Разделите книгу.');
 let cells=0,rows=0;const sheets=[];
 for(const name of book.SheetNames){const sheet=book.Sheets[name],groups=new Map();
  for(const address of Object.keys(sheet).filter(k=>/^[A-Z]+[1-9]\d*$/.test(k))){const c=sheet[address];if(c.v===undefined&&!c.f)continue;if(++cells>limits.cells)throw Error('В Excel больше 20 000 непустых ячеек. Разделите перечень.');const pos=XLSX.utils.decode_cell(address);if(!groups.has(pos.r)){if(++rows>limits.rows)throw Error('В Excel больше 5 000 строк. Разделите перечень.');groups.set(pos.r,[]);}
   const value=c.v===undefined?null:c.v;let text=address+'='+JSON.stringify(value);if(c.w!==undefined&&String(c.w)!==String(value))text+=' (отображение '+JSON.stringify(c.w)+')';if(c.f)text+=' [формула '+JSON.stringify(c.f)+'; '+(c.v===undefined?'сохранённого результата нет':'сохранённый результат')+']';if(c.t==='e')text+=' [ОШИБКА ЯЧЕЙКИ]';groups.get(pos.r).push({col:pos.c,text});
  }
  const merged=(sheet['!merges']||[]).map(r=>XLSX.utils.encode_range(r));
  sheets.push('ЛИСТ '+JSON.stringify(name)+(book.Workbook?.Sheets?.[book.SheetNames.indexOf(name)]?.Hidden?' [скрытый]':'')+'\n'+(merged.length?'Объединённые ячейки: '+merged.join(', ')+'\n':'')+[...groups].sort(([a],[b])=>a-b).map(([row,items])=>'Строка '+(row+1)+': '+items.sort((a,b)=>a.col-b.col).map(c=>c.text).join(' | ')).join('\n'));
 }
 if(!cells)throw Error('В Excel нет текстовых или числовых данных. Скан или рисунок в книге приложите как PDF/изображение.');
 const result='ТАБЛИЦА ИЗ EXCEL '+JSON.stringify(file.name)+'\nЛистов: '+book.SheetNames.length+'; непустых строк: '+rows+'; непустых ячеек: '+cells+'.\n'+sheets.join('\n\n');
 if(result.length>limits.characters)throw Error('Текст Excel превышает 240 000 символов. Разделите перечень, чтобы строки не потерялись.');return result;
}
