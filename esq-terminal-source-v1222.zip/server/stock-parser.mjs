// Keep warehouse evidence inside the selected product, never recommendation cards.
export function parseStock(html){
 const cleanStock=s=>String(s||'').replace(/<script\b[\s\S]*?<\/script>/gi,'').replace(/<style\b[\s\S]*?<\/style>/gi,'').replace(/<[^>]*>/g,' ').replace(/&nbsp;|&#(?:160|x0*a0);/gi,' ').replace(/\s+/g,' ').trim();
 const divBlock=(text,start)=>{let depth=0;const tags=/<\/?div\b[^>]*>/gi;tags.lastIndex=start;let m;while((m=tags.exec(text))){depth+=/^<\//.test(m[0])?-1:1;if(depth===0)return text.slice(start,tags.lastIndex);}return '';};
 const primary=/<div\b[^>]*class=["'][^"']*\bproduct_item__content-order--props\b[^"']*["'][^>]*>/i.exec(html);
 const scope=primary?divBlock(html,primary.index):html.split(/<(?:section|div)\b[^>]*class=["'][^"']*(?:related-products|accessory-container|recommend)[^"']*["']/i)[0];
 const dialog=/<div\b[^>]*id=["']dialog_m_amount["'][^>]*>/i.exec(scope);
 const block=dialog?divBlock(scope,dialog.index):'';
 const priorities=['Санкт-Петербург','Москва','Краснодар','Ставрополь'];
 const keys=['Питер','Москва','Краснодар','Ставрополь'];
 const normalize=s=>cleanStock(s).replace(/:$/,'').replace(/^(?:Санкт[ -]Петербург|СПб|Питер)$/i,'Санкт-Петербург');
 const quantity=s=>{const m=cleanStock(s).match(/^(\d+(?: \d{3})*)\s*(?:шт\.?|ед\.?)(?:\s|$)/i);return m?Number(m[1].replace(/ /g,'')):null;};
 const counts={},statuses={},evidence=[],issues=[];let otherTotal=null,rows=0,knownRows=0;
 const save=(city,raw)=>{city=normalize(city);const n=quantity(raw);if(n!==null){if(counts[city]!==undefined&&counts[city]!==n){counts[city]=null;issues.push('Противоречивое количество: '+city);}else if(counts[city]!==null)counts[city]=n;}
  const text=cleanStock(raw);if(n===null&&text)statuses[city]=text.slice(0,160);evidence.push({warehouse:city,quantity:n,text:text.slice(0,160)});return n;};
 for(const m of scope.matchAll(/<div\b[^>]*class=["'][^"']*\bcard_prop__row\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/gi)){
  const cells=[...m[1].matchAll(/<span\b[^>]*>([\s\S]*?)<\/span>/gi)];if(cells.length<2)continue;
  const city=normalize(cells[0][1]);if(city==='Другие склады'){otherTotal=quantity(cells[1][1]);continue;}if(priorities.includes(city))save(city,cells[1][1]);
 }
 for(const m of block.matchAll(/<div\b[^>]*class=["'][^"']*\ball_amount_city__item\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/gi)){
  const city=m[1].match(/<span\b[^>]*>([\s\S]*?)<\/span>/i),value=m[1].match(/<strong\b[^>]*>([\s\S]*?)<\/strong>/i);if(!city||!value)continue;rows++;if(save(city[1],value[1])!==null)knownRows++;
 }
 const listed=Object.entries(counts).filter(([city])=>city!=='Санкт-Петербург');
 const complete=!!block&&otherTotal!==null&&rows===knownRows&&!issues.length&&listed.every(([,n])=>n!==null)&&listed.reduce((sum,[,n])=>sum+n,0)===otherTotal;
 const stock={},warehouse_status={};priorities.forEach((city,i)=>{stock[keys[i]]=counts[city]??(i>0&&complete?0:null);if(stock[keys[i]]===null&&statuses[city])warehouse_status[keys[i]]=statuses[city];});
 stock['Остальные склады']=complete?listed.filter(([city])=>!priorities.includes(city)).reduce((sum,[,n])=>sum+n,0):null;
 return {stock,warehouse_status,stock_evidence:evidence,stock_date:cleanStock(block).match(/Актуально на\s+(\d{2}\.\d{2}\.\d{4})/i)?.[1]||null,other_warehouses_total:otherTotal,full_warehouse_listing:complete,first_four_confirmed_empty:keys.every(k=>stock[k]===0),...(issues.length?{stock_warnings:issues}:{})};
}
