// Synchronous adapters for Google Apps Script V8. Only server-side code uses these.
function gunzipJSON_(encoded) { return JSON.parse(Utilities.ungzip(Utilities.newBlob(Utilities.base64Decode(encoded))).getDataAsString()); }
const AbortSignal = {timeout() { return undefined; }};
const syncAll = values => values;
function atob(value) { return Utilities.base64Decode(value).map(x=>String.fromCharCode(x & 255)).join(''); }
function btoa(value) { return Utilities.base64Encode(Array.from(value,c=>{const n=c.charCodeAt(0);return n>127?n-256:n;})); }
class TextDecoder { decode(value) { return Utilities.newBlob(Array.from(value||[],x=>x>127?x-256:x)).getDataAsString(); }}
class URLSearchParams { constructor(values) { this.values=values; } toString() { return Object.entries(this.values).map(([k,v])=>encodeURIComponent(k)+'='+encodeURIComponent(v)).join('&'); }}
class FormData { constructor(){this.fields={};} append(key,value){this.fields[key]=value;} }
class URL {
 constructor(value,base) {
  value=String(value);if(base&&!/^[a-z][a-z0-9+.-]*:/i.test(value)){const b=new URL(base);value=value.startsWith('//')?b.protocol+value:b.origin+(value.startsWith('/')?value:b.pathname.slice(0,b.pathname.lastIndexOf('/')+1)+value);}
  const match=/^(https?:)\/\/([^/?#]+)([^?#]*)(\?[^#]*)?(#.*)?$/.exec(value);if(!match)throw Error('Invalid URL');
  this.protocol=match[1];let authority=match[2];this.username='';this.password='';if(authority.includes('@')){const at=authority.lastIndexOf('@');const credentials=authority.slice(0,at).split(':');this.username=credentials[0];this.password=credentials.slice(1).join(':');authority=authority.slice(at+1);}
  const host=authority.split(':');this.hostname=host[0].toLowerCase();this.port=host[1]||'';this.origin=this.protocol+'//'+authority;this.pathname=match[3]||'/';this.search=match[4]||'';this.hash=match[5]||'';
 }
 get href(){return this.toString();} toString(){return this.origin+this.pathname+this.search+this.hash;}
}
function fetch(url,options={}) {
 const opts={method:(options.method||'GET').toLowerCase(),headers:options.headers||{},muteHttpExceptions:true,followRedirects:options.redirect!=='manual'&&options.redirect!=='error'};
 if(options.body!==undefined){opts.payload=options.body instanceof FormData?options.body.fields:options.body;const type=opts.headers['Content-Type']||opts.headers['content-type'];if(type)opts.contentType=type;}
 const response=UrlFetchApp.fetch(String(url),opts),status=response.getResponseCode(),headers=response.getAllHeaders();
 let read=false;
 return {status,ok:status>=200&&status<300,text:()=>response.getContentText(),json:()=>JSON.parse(response.getContentText()),headers:{get(name){const key=Object.keys(headers).find(k=>k.toLowerCase()===name.toLowerCase());return key?String(headers[key]):null;}},body:{getReader(){return {read(){if(read)return {done:true};read=true;return {done:false,value:Uint8Array.from(response.getBlob().getBytes(),x=>x&255)};},cancel(){read=true;}};}}};
}
