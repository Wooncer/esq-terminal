function doGet() { return json_({ok:true, service:"esq-gemini-relay"}); }
function json_(data) { return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON); }
function doPost(e) {
  try {
    if (!e || !e.postData || e.postData.contents.length > 24*1024*1024) return json_({status:413,error:"Request too large"});
    const data = JSON.parse(e.postData.contents);
    if (data.action === 'web-api') {
      if (!((data.method === 'GET' && ['/api/status','/api/models'].indexOf(data.path)>=0) || (data.method === 'POST' && data.path === '/api/chat'))) return json_({status:404,body:JSON.stringify({error:'Unknown API method'})});
      const properties=PropertiesService.getScriptProperties();
      const apiKey=properties.getProperty('GEMINI_API_KEY')||'';
      const quotas=JSON.parse(properties.getProperty('GEMINI_QUOTAS_JSON')||'{}');
      const response=UrlFetchApp.fetch('https://raw.githubusercontent.com/Wooncer/esq-terminal/main/esq-gas-runtime.js.gz');
      const blob=response.getBlob();
      const digest=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,blob.getBytes()).map(x=>(x&255).toString(16).padStart(2,'0')).join('');
      if(digest!=='4501c2811da4c9765a9f5f63924c85cc9ccfbf81a4a72cc14ddb0da811d6ba4e') throw Error('Runtime checksum mismatch');
      const source=Utilities.ungzip(blob).getDataAsString();
      return json_(eval(source+'\n gasHandle(data,apiKey,quotas);'));
    }
    const expected = "REPLACE_WITH_PRIVATE_64_CHAR_TOKEN";
    let diff = String(data.token || "").length ^ expected.length;
    for (let i=0;i<expected.length;i++) diff |= expected.charCodeAt(i) ^ (String(data.token || "").charCodeAt(i) || 0);
    if (diff) return json_({status:401,error:"Unauthorized"});
    if (data.action === 'configure') {
      if(typeof data.key!=='string'||data.key.length<20)return json_({status:400,error:'Invalid configuration'});
      PropertiesService.getScriptProperties().setProperties({GEMINI_API_KEY:data.key,GEMINI_QUOTAS_JSON:JSON.stringify(data.quotas||{})});
      return json_({status:200,configured:true});
    }
    if (data.action === "diagnostics") {
      const trace = UrlFetchApp.fetch("https://www.cloudflare.com/cdn-cgi/trace", {muteHttpExceptions:true}).getContentText();
      return json_({status:200,body:trace,contentType:"text/plain"});
    }
    const method = data.method || "GET";
    const path = data.path || "";
    const allowed = (method === "GET" && path === "/v1beta/models") || (method === "POST" && /^\/v1beta\/models\/gemini-[a-zA-Z0-9._-]+:generateContent$/.test(path));
    if (!allowed || typeof data.key !== "string" || !data.key) return json_({status:400,error:"Invalid Gemini request"});
    const options = {method:method.toLowerCase(),headers:{"x-goog-api-key":data.key},muteHttpExceptions:true,followRedirects:false};
    if (method === "POST") { options.contentType="application/json"; options.payload=data.body; }
    const response = UrlFetchApp.fetch("https://generativelanguage.googleapis.com" + path, options);
    return json_({status:response.getResponseCode(),contentType:"application/json",body:response.getContentText()});
  } catch (error) { return json_({status:502,error:"Relay request failed"}); }
}
