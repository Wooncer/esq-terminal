function gasHandle(request, apiKey, quotas) {
 try {
  if(request.path==='/api/status')return {status:200,body:JSON.stringify({connected:!!apiKey,csrf:'google-public-api',provider:'gemini',route:'google-apps-script-standalone',access:{mode:'guest',guestAllowed:true},quotas:quotas||{},email:apiKey?'Gemini API + ESQ':null})};
  if(!apiKey)return {status:503,body:JSON.stringify({error:'Сервер Google ещё не настроен'})};
  if(request.path==='/api/models'&&request.method==='GET')return {status:200,body:JSON.stringify({models:geminiModelList(apiKey)})};
  if(request.path==='/api/chat'&&request.method==='POST'){
   const data=JSON.parse(request.body);boundedInput(data.input);const events=[];
   for(const event of geminiChat(data,apiKey,undefined,{boundedInput,compact,instructions,tools,exposed,callTool,validateArguments}))events.push(event);
   return {status:200,contentType:'application/x-ndjson',body:events.map(e=>JSON.stringify(e)).join('\n')+'\n'};
  }
  return {status:404,body:JSON.stringify({error:'API method unavailable'})};
 }catch(error){return {status:502,body:JSON.stringify({error:String(error.message||error).slice(0,500)})};}
}
