# Принципы, применённые к ESQ Terminal

Применены инструкции Sites и OpenAI Docs для реализации, а не случайные «универсальные промпты» из подборок. Никакие сторонние пакеты навыков с неизвестным кодом не установлены.

## Работа с сайтом и API

- Проверять существующие исходники и сохранять бизнес-правила.
- Разделять инструкции разработчика, запрос пользователя и недоверенное содержимое каталогов/вложений.
- Давать инструментам короткие конкретные описания и проверять аргументы на сервере.
- Использовать локальный поиск, передавать модели только нужные страницы и ограниченную историю.
- Хранить авторизацию вне HTML и git; проверять PKCE, state, nonce, подпись, issuer и audience.
- Проверять поток до response.completed. Различать незавершённый ответ и успешный; учитывать usage по каждому завершённому раунду.
- Не превращать отсутствие данных в нулевые остатки и не объявлять кандидатов готовым составом.

## Примеры запросов к подбору

«Подбери АИР 3/1420 на лапах. Сопоставь с 5АИ по каталогу. Подтверди артикул и остатки по четырём приоритетным складам. Неизвестное пометь отдельно.»

«Подбери NMRV 110-56-3-B3. Проверь редуктор, двигатель и нужные аксессуары. Сначала точные выходные обороты, затем допуск ±15%. Укажи источники и неподтверждённые параметры.»

«По фото шильдика извлеки модель, мощность, обороты и монтаж. Нечитаемые символы не угадывай. Затем подбери по этим параметрам и проверь наличие.»

## Официальные источники, проверенные при реализации

- Prompt engineering: https://developers.openai.com/api/docs/guides/prompt-engineering
- Sign in with ChatGPT: https://developers.openai.com/siwc/quickstart
- Локальный вход: https://developers.openai.com/siwc/token-sharing-open-source/sign-in
- Запросы и модели: https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference
- Ограничения подписки, поддерживаемые поля и инструменты: https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations
- Файлы: https://developers.openai.com/api/docs/guides/file-inputs
- Function / namespace schema: https://developers.openai.com/api/reference/resources/responses/methods/create
- GitHub Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- Публикация: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
