import fs from 'node:fs';
let engine=fs.readFileSync('web/esq-engine.js','utf8').replace(/export \{[^}]+\};\s*$/,'');
const local=fs.readFileSync('server/local.mjs','utf8');const declarations=local.slice(local.indexOf('const exposed='),local.indexOf('function json('));
const protocol=fs.readFileSync('server/protocol.mjs','utf8').replaceAll('export ','');
const gemini=fs.readFileSync('server/gemini.mjs','utf8').replace(/^import[^\n]+\nconst DRIVE_POLICY=rules.workflow;\n/,'').replaceAll('export ','');
const relay=fs.readFileSync('server/gemini-relay.mjs','utf8').replaceAll('export ','');
const assets={};for(const [file,type]of [['index.html','text/html; charset=utf-8'],['app.js','text/javascript; charset=utf-8'],['markdown.js','text/javascript; charset=utf-8'],['style.css','text/css; charset=utf-8']])assets['/'+file]={body:fs.readFileSync('web/'+file,'utf8'),type};
fs.mkdirSync('worker',{recursive:true});fs.writeFileSync('worker/index.js',engine+'\n'+declarations+'\n'+protocol+'\n'+gemini+'\n'+relay+'\nconst ASSETS='+JSON.stringify(assets)+';\n'+fs.readFileSync('scripts/hosted-runtime.js','utf8'));
