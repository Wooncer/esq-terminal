import fs from 'node:fs';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
let engine=fs.readFileSync('web/esq-engine.js','utf8').replace(/export \{[^}]+\};\s*$/,'');
engine=engine.replace("JSON.parse(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text())",'gunzipJSON_(ASSORTMENT_GZIP)');
engine=engine.replace("const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));\n const value=JSON.parse(await new Response(stream).text());",'const value=gunzipJSON_(catalog.pages_gzip);');
engine=engine.replace("JSON.parse(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text())",'gunzipJSON_(CATALOG_SEARCH_GZIP)');
const local=fs.readFileSync('server/local.mjs','utf8');const declarations=local.slice(local.indexOf('const exposed='),local.indexOf('function json('));
let protocol=fs.readFileSync('server/protocol.mjs','utf8').split('\n').filter(x=>!x.includes('sseEvents')).join('\n').replaceAll('export ','');
let gemini=fs.readFileSync('server/gemini.mjs','utf8').replace(/^import[^\n]+\nconst DRIVE_POLICY=rules.workflow;\n/,'').replaceAll('export ','');
let runtime=[fs.readFileSync('deploy/gas-compat.js','utf8'),engine,declarations,protocol,gemini,fs.readFileSync('deploy/gas-api.js','utf8')].join('\n');
// The original engine awaits only HTTP, decompression and tool calls, all synchronous above.
runtime=runtime.replace(/\basync\s+/g,'').replace(/\bawait\s+/g,'').replaceAll('Promise.all(', 'syncAll(');
fs.writeFileSync('deploy/esq-gas-runtime.js',runtime);
const archive=zlib.gzipSync(runtime);fs.writeFileSync('web/esq-gas-runtime.js.gz',archive);
console.log(JSON.stringify({bytes:archive.length,sha256:crypto.createHash('sha256').update(archive).digest('hex')}));
