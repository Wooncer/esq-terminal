import test from 'node:test';import assert from 'node:assert/strict';import worker from '../worker/index.js';
const base='https://esq.example';const identity={'oai-authenticated-user-id':'test-owner'};
test('hosted app is chat-only and cannot invent answers without model credentials',async()=>{const r=await worker.fetch(new Request(base),{},{});const html=await r.text();assert(!html.includes('data-prompt'));assert(!html.includes('id="catalogs"'));assert(!html.includes('value="catalog"'));assert(html.includes('id="messages"'));const s=await worker.fetch(new Request(base+'/api/status',{headers:identity}),{},{});assert.equal((await s.json()).connected,false);const missing=await worker.fetch(new Request(base+'/api/chat',{method:'POST',headers:identity}),{},{});assert.equal(missing.status,503);const anonymous=await worker.fetch(new Request(base+'/api/models'),{GEMINI_API_KEY:'fixture'},{});assert.equal(anonymous.status,401)});
test('platform sign-in with email but without ID remains authenticated',async()=>{const r=await worker.fetch(new Request(base+'/api/status',{headers:{'oai-authenticated-user-email':'owner@example.com'}}),{GEMINI_API_KEY:'fixture'},{});assert.equal(r.status,200);assert.equal((await r.json()).connected,true);const anonymous=await worker.fetch(new Request(base+'/api/status'),{GEMINI_API_KEY:'fixture'},{});assert.equal(anonymous.status,401)});
test('guest access requires explicit server setting and preserves same-origin chat protection',async()=>{
 const enabled={GEMINI_API_KEY:'fixture-secret',ESQ_ALLOW_GUEST:'true'};
 const status=await worker.fetch(new Request(base+'/api/status'),enabled,{});
 assert.equal(status.status,200);const data=await status.json();
 assert.equal(data.access.mode,'guest');assert.equal(data.access.guestAllowed,true);
 assert.equal(data.access.signInUrl,'/signin-with-chatgpt?returnTo=%2F');
 assert(!JSON.stringify(data).includes('fixture-secret'));
 const signed=await worker.fetch(new Request(base+'/api/status',{headers:identity}),enabled,{});
 assert.equal((await signed.json()).access.mode,'account');
 const badOrigin=await worker.fetch(new Request(base+'/api/chat',{method:'POST',headers:{Origin:'https://other.example'}}),enabled,{});
 assert.equal(badOrigin.status,403);
 const noKey=await worker.fetch(new Request(base+'/api/chat',{method:'POST'}),{ESQ_ALLOW_GUEST:'true'},{});
 assert.equal(noKey.status,503);
});

test('GitHub Pages CORS accepts only the intended origin in guest mode',async()=>{
 const enabled={ESQ_ALLOW_GUEST:'true',GEMINI_API_KEY:'fixture'};
 const origin='https://wooncer.github.io';
 const preflight=await worker.fetch(new Request(base+'/api/chat',{method:'OPTIONS',headers:{Origin:origin}}),enabled,{});
 assert.equal(preflight.status,204);assert.equal(preflight.headers.get('Access-Control-Allow-Origin'),origin);
 const status=await worker.fetch(new Request(base+'/api/status',{headers:{Origin:origin}}),enabled,{});
 assert.equal(status.headers.get('Access-Control-Allow-Origin'),origin);assert.equal((await status.json()).access.mode,'guest');
 const denied=await worker.fetch(new Request(base+'/api/chat',{method:'OPTIONS',headers:{Origin:'https://other.example'}}),enabled,{});assert.equal(denied.status,403);assert.equal(denied.headers.get('Access-Control-Allow-Origin'),null);
 const disabled=await worker.fetch(new Request(base+'/api/status',{headers:{Origin:origin}}),{},{});assert.equal(disabled.status,401);assert.equal(disabled.headers.get('Access-Control-Allow-Origin'),null);
});
