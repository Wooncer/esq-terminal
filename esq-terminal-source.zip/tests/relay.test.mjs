import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createGeminiFetcher} from '../server/gemini-relay.mjs';

const env={GEMINI_RELAY_URL:'https://script.google.com/macros/s/test-deployment/exec',GEMINI_RELAY_TOKEN:'fixture-token'};
test('Gemini relay forwards credentials only inside HTTPS body and preserves upstream errors',async()=>{
 let calls=0;
 const fetcher=createGeminiFetcher(env,async(url,options)=>{
   calls++; assert.equal(url,env.GEMINI_RELAY_URL);assert.equal(new Headers(options.headers).get('x-goog-api-key'),null);
   const data=JSON.parse(options.body);assert.equal(data.key,'fixture-google-key');assert.equal(data.token,env.GEMINI_RELAY_TOKEN);assert.equal(data.path,'/v1beta/models');
   return Response.json({status:429,body:'{"error":{"message":"quota"}}'});
 });
 const response=await fetcher('https://generativelanguage.googleapis.com/v1beta/models',{headers:{'x-goog-api-key':'fixture-google-key'}});
 assert.equal(response.status,429);assert.equal((await response.json()).error.message,'quota');assert.equal(calls,1);
});
test('configured relay fails closed and leaves catalogue fetches unchanged',async()=>{
 let calls=[]; const relay=createGeminiFetcher(env,async(url)=>{calls.push(url);return new Response('not json');});
 await assert.rejects(relay('https://generativelanguage.googleapis.com/v1beta/models'),/неверный ответ/);assert.equal(calls.length,1);
 await assert.rejects(relay('https://generativelanguage.googleapis.com/v1beta/files'),/Недопустимый/);assert.equal(calls.length,1);
 await relay('https://catalog.example/original.pdf');assert.equal(calls[1],'https://catalog.example/original.pdf');
 assert.throws(()=>createGeminiFetcher({...env,GEMINI_RELAY_URL:'https://untrusted.example/'}),/Неверная/);
});
test('Apps Script rejects anonymous requests and arbitrary destinations',()=>{
 let calls=0; const context={ContentService:{MimeType:{JSON:'application/json'},createTextOutput(text){return {text,setMimeType(){return this;}};}},UrlFetchApp:{fetch(url,options){calls++;assert.equal(url,'https://generativelanguage.googleapis.com/v1beta/models');assert.equal(options.headers['x-goog-api-key'],'fixture-key');return {getResponseCode:()=>200,getContentText:()=>'{"models":[]}'};}}};
 vm.createContext(context);vm.runInContext(fs.readFileSync(new URL('../deploy/google-apps-script.gs',import.meta.url),'utf8'),context);
 const post=data=>JSON.parse(context.doPost({postData:{contents:JSON.stringify(data)}}).text);
 assert.equal(post({token:'wrong'}).status,401);assert.equal(calls,0);
 const token='REPLACE_WITH_PRIVATE_64_CHAR_TOKEN';
 assert.equal(post({token,path:'https://evil.example/',key:'fixture-key'}).status,400);assert.equal(calls,0);
 assert.equal(post({token,path:'/v1beta/models',key:'fixture-key'}).status,200);assert.equal(calls,1);
});
