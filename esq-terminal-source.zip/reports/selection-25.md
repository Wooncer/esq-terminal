# Проверка 25 запросов

Проверен реальный prepare_selection локального движка. Это не 25 ответов Gemini и не подтверждение механической совместимости всех изделий. Неизвестные комплекты не объявляются готовыми. Размерные граничные проверки — отдельно tests/drive.test.mjs; их размеры синтетические.

| Запрос | Статус | Карточки | Готовый комплект |
|---|---|---:|---|
| NMRV 075-56-1.5-B3 | requires_engineering_verification | 6 | нет |
| NMRV 110-56-3-B3 | requires_engineering_verification | 0 | нет |
| NMRV 110-60-3-B3 | requires_engineering_verification | 6 | нет |
| NMRV 110-45-3-B3 | requires_engineering_verification | 6 | нет |
| NMRV 075-56-1.5-B8 | requires_engineering_verification | 6 | нет |
| NMRV 063-28-0.75-B3 | requires_engineering_verification | 6 | нет |
| NMRV 050-70-0.37-B3 | requires_engineering_verification | 6 | нет |
| NMRV 090-28-2.2-B3 | requires_engineering_verification | 6 | нет |
| NMRV 130-14-5.5-B3 | requires_engineering_verification | 6 | нет |
| Червячный редуктор 075 56 оборотов 1.5 кВт | requires_engineering_verification | 0 | нет |
| Редуктор 80B5 и двигатель 80B14 | requires_engineering_verification | 0 | нет |
| Редуктор IEC 80B5 и двигатель ГОСТ 80 B5 | requires_engineering_verification | 0 | нет |
| NMRV 075 с тормозным двигателем | requires_engineering_verification | 0 | нет |
| NMRV 110 с ручным растормаживанием | requires_engineering_verification | 0 | нет |
| NMRV 075 1.5 кВт 56 оборотов B14 | requires_engineering_verification | 0 | нет |
| Д 630-90 | requires_engineering_verification | 6 | нет |
| Д200-90 с 75 кВт | requires_engineering_verification | 3 | нет |
| Д200-90а | requires_engineering_verification | 6 | нет |
| К 290/30 | requires_engineering_verification | 6 | нет |
| ЦН 1000-180 | requires_engineering_verification | 2 | нет |
| Насос Д630-90 без двигателя | requires_engineering_verification | 6 | нет |
| 5АИ80В4 IM3081 | requires_engineering_verification | 2 | нет |
| двигатель IEC 80 B14 | requires_engineering_verification | 0 | нет |
| частотник 15 кВт | requires_engineering_verification | 0 | нет |
| итальянский двигатель 0.37/1500 малый фланец | requires_engineering_verification | 0 | нет |


После правки ведущего нуля карточки находятся для NMRW075/063/050/090. Прямые запросы малых фланцев больше не подменяются автоматическим подбором ГОСТ. Полный прогон 25 ответов Gemini не выполнен: запрос к приватному /api/chat вернул HTTP 401. Это ограничение авторизации проверки, а не результат инженерного подбора. Всего 29 автоматических тестов прошли.
