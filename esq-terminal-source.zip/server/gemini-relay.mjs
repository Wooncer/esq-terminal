// Apps Script keeps transport authentication on the server, never in browser assets.
export function createGeminiFetcher(env, fetcher = fetch) {
  if (!env.GEMINI_RELAY_URL) return fetcher;
  const relay = new URL(env.GEMINI_RELAY_URL);
  if (relay.origin !== 'https://script.google.com' || !/^\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(relay.pathname) || relay.search || relay.hash || relay.username || relay.password || !env.GEMINI_RELAY_TOKEN) throw Error('Неверная настройка шлюза Gemini');
  return async (url, options = {}) => {
    const upstream = new URL(url);
    // Catalogue documents and other tools retain their original transport.
    if (upstream.origin !== 'https://generativelanguage.googleapis.com') return fetcher(url, options);
    const method = options.method || 'GET';
    if (upstream.search || upstream.hash || upstream.username || upstream.password || !((method === 'GET' && upstream.pathname === '/v1beta/models') || (method === 'POST' && /^\/v1beta\/models\/gemini-[a-zA-Z0-9._-]+:generateContent$/.test(upstream.pathname)))) throw Error('Недопустимый запрос к шлюзу Gemini');
    const response = await fetcher(relay.href, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({token: env.GEMINI_RELAY_TOKEN, path: upstream.pathname, method, key: new Headers(options.headers).get('x-goog-api-key'), body: options.body}),
      signal: options.signal, redirect: 'follow'
    });
    if (!response.ok) throw Error('Шлюз Gemini недоступен: HTTP ' + response.status);
    let result;
    try { result = await response.json(); } catch { throw Error('Шлюз Gemini вернул неверный ответ'); }
    if (!Number.isInteger(result.status) || result.status < 200 || result.status > 599 || typeof result.body !== 'string') throw Error('Шлюз Gemini не выполнил запрос');
    return new Response(result.body, {status: result.status, headers: {'Content-Type': 'application/json'}});
  };
}
