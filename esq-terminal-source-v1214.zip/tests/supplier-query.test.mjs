import test from 'node:test';
import assert from 'node:assert/strict';
import {supplierModelQuery,callTool} from '../web/esq-engine.js';
import {geminiChat,exact230Evidence} from '../server/gemini.mjs';
import {boundedInput,compact} from '../server/protocol.mjs';
test('supplier search extracts model from prose',async()=>{
 const query='Подбери частотный преобразователь ESQ-230-4T-4K, 4 кВт, 380 В. Укажи точный артикул, ссылку на карточку и свежее наличие отдельно: Питер, Москва, Краснодар, Ставрополь, остальные склады. Неизвестные остатки не заменяй нулями.';
 const result=await callTool('prepare_selection',{request:query});
 assert.equal(result.resolved_query,'ESQ-230-4T-4K');assert(result.cards.some(c=>c.url.endsWith('/esq_230_4t_4k/')));
});
test('gear slash not motor power speed',async()=>{
 const result=await callTool('prepare_selection',{request:'Подбери мотор-редуктор NMRW110-25/100B5, двигатель 3 кВт, 4 полюса IM3081. Укажи артикулы и наличие.'});
 assert.equal(result.status,'requires_engineering_verification');assert.equal(result.resolved_query,'NMRW110-25/100B5');assert(result.cards.length>0);
});
test('model extraction preserves distinct pump and gear designations',()=>{
 for(const [request,expected] of [
 ['Только насосная часть: Насос 1Д 200-90а под 75кВт б/дв','1Д 200-90а'],
 ['Насос КМ 50-32-125 СД под 2.2кВт','КМ 50-32-125'],
 ['Насос К 290/30 под 37кВт','К 290/30'],
 ['Насос НМШ 5-25-4/4 под 1.5кВт','НМШ 5-25-4/4'],
 ['Редуктор KA47- 19.58/90В5, двигатель 2.2 кВт','KA47-19.58/90B5'],
 ['Редуктор R37U- 6.67/90В5','R37U-6.67/90B5'],
 ['DRW 040/063, i=100','DRW 040/063'],
 ['ESQ-230-2S-0.4K, 220 В','ESQ-230-2S-0.4K'],
 ])assert.equal(supplierModelQuery(request),expected,request);
 assert.equal(supplierModelQuery('Подбери насос Q=100 H=40'),null);
});
test('unique card verified before model using real engine array-shaped stock',async()=>{
 const invoked=[];let modelCalls=0;const url='https://www.elcomspb.ru/retail/invertors/frequency_converters/esq_230_4t_4k/';const events=[];
 const verified={url,title:'Преобразователь ESQ-230-4T-4K',article:'08.04.304426',stock:{Питер:44,Москва:0,Краснодар:28,Ставрополь:1,'Остальные склады':140},checked_at:'2026-11-04T18:42:37Z'};
 for await(const e of geminiChat({model:'gemini-3.5-flash-lite',input:[{role:'user',text:'Подбери ESQ-230-4T-4K, укажи наличие'}],files:[]},'test',undefined,{boundedInput,compact,instructions:'Подбор',tools:[],exposed:['get_component_stock'],validateArguments:()=>{},callTool:async(name)=>{invoked.push(name);return name==='prepare_selection'?{resolved_query:'ESQ-230-4T-4K',cards:[{url}]}:[verified];},fetcher:async(u,o)=>{modelCalls++;assert.deepEqual(invoked,['prepare_selection','get_component_stock']);assert(JSON.parse(o.body).contents.at(-1).parts[0].text.includes('08.04.304426'));return Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:'ESQ-230-4T-4K, артикул 08.04.304426'}]}}]});}}))events.push(e);
 assert(events.find(e=>e.type==='delta').text.includes('](https://www.elcomspb.ru/retail/invertors/frequency_converters/esq_230_4t_4k/)'));
 assert.equal(modelCalls,1);assert(events.find(e=>e.type==='delta').text.includes('| 08.04.304426 | 44 | 0 | 28 | 1 | 140 |'));
});
test('30 audit designations retain all 27 known cards; DRW remains catalog-only candidate',async()=>{
 const {readFile}=await import('node:fs/promises');const cases=JSON.parse(await readFile(new URL('./fixtures/audit30-search.json',import.meta.url),'utf8'));
 for(const c of cases){const r=await callTool('prepare_selection',{request:c.prompt});if(c.url)assert(r.cards.some(x=>x.url===c.url),c.id+' lost expected supplier card');else assert.equal(r.status,'requires_engineering_verification',c.id);}
});

test('exact ESQ230 rendering requires matching catalogue row and preserves request conflicts',()=>{
 const item={article:'08.04.304486',url:'https://www.elcomspb.ru/retail/invertors/frequency_converters/esq-230-4t-30k/',attributes:{'Модель':'ESQ-230-4T-30K','Мощность (кВт)':'30','Номинальный выходной ток (А)':'60','Напряжение (В)':'380','Количество фаз':'3'},stock:{Питер:null,Москва:0,Краснодар:0,Ставрополь:0,'Остальные склады':1},warehouse_status:{Питер:'с 12 ноя'}};
 const p={resolved_query:'ESQ-230-4T-30K',verified_components:[item],catalog:{items:[{source:'Каталог ПЧ и УПП ESQ.pdf',page:5,text:'ESQ-230-4T-30K 43 60 30'}]}};
 const out=exact230Evidence(p,'Подбери ESQ-230-4T-30K 30кВт, 380В.');assert(out.includes('не является двойным номиналом'));assert(out.includes('| 08.04.304486 | с 12 ноя | 0 | 0 | 0 | 1 |'));assert(out.includes('страница PDF 5'));
 assert(exact230Evidence(p,'ESQ-230-4T-30K 4 кВт, 220 В').includes('Несоответствие требованиям'));
 assert.equal(exact230Evidence({...p,catalog:{items:[]}},'ESQ'),null);assert.equal(exact230Evidence({...p,verified_components:[{...item,error:'offline'}]},'ESQ'),null);
});
