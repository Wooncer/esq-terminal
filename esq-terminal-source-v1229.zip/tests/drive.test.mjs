import test from 'node:test';import assert from 'node:assert/strict';import {checkDriveCompatibility as check,resolveDoubleWorm,resolveGearMotor} from '../web/esq-engine.js';
import {renderDoubleWorm} from '../server/gemini.mjs';
const dim={frame:80,flange:'B5',standard:'IEC',shaft_diameter:19,shaft_length:40,pilot_diameter:130,bolt_circle:165,hole_diameter:12,bolt_count:4,source:'Тестовый чертёж: синтетические размеры, не каталог'};
for(const flange of ['B14','B34'])test('reject IEC 80B5 / '+flange,()=>assert.equal(check(dim,{...dim,flange}).status,'incompatible'));
for(const k of ['shaft_diameter','shaft_length','pilot_diameter','bolt_circle','hole_diameter','bolt_count'])test('reject differing '+k,()=>assert.equal(check(dim,{...dim,[k]:dim[k]+1}).status,'incompatible'));
test('standard label alone does not reject equal documented interfaces',()=>assert.equal(check(dim,{...dim,standard:'GOST'}).status,'compatible'));
test('same B5 label alone proves nothing',()=>assert.equal(check({frame:80,flange:'B5'},{frame:80,flange:'B5'}).status,'unverified'));
test('B35 flange can match B5 only with dimensions and sources',()=>assert.equal(check(dim,{...dim,flange:'B35'}).status,'compatible'));
import fs from 'node:fs';
const rows=JSON.parse(fs.readFileSync(new URL('./fixtures/gear-config.json',import.meta.url)));const stock=JSON.parse(fs.readFileSync(new URL('./fixtures/gear-stock.json',import.meta.url)));
const input={frame:63,power_kw:0.75,output_rpm:54,mount:'B3'};
const invoke=async(name,args)=>{assert.equal(name,'get_component_stock');assert.equal(args.refresh,true);return args.urls.map(url=>stock.find(x=>x.url===url)||{url,error:'fixture not found'})};
test('actual configurator 063-54-0.75 returns complete stock-checked ГОСТ71/80B5 kit',async()=>{const r=await resolveGearMotor(input,async(url,opt)=>{assert.equal(opt.body.get('mgearfrom'),'54');assert.equal(opt.body.get('mgearto'),'54');return Response.json(rows)},invoke);assert.equal(r.selection_complete,true);assert.equal(r.combinations[0].reducer.article,'07.01.01.000074');assert.equal(r.combinations[0].motor.article,'01.01.213536');assert.equal(r.combinations[0].motor.stock.Питер,56);assert(r.combinations[0].notes[0].includes('IM2081'))});
test('no arbitrary pairing when current reducer flange differs from configurator',async()=>{const r=await resolveGearMotor(input,async()=>Response.json(rows),async(n,a)=>a.urls.map(url=>{const s=stock.find(x=>x.url===url);return s?{...s,attributes:{...s.attributes,'Типоразмер фланца':'80B14'}}:{url,error:'missing'}}));assert.equal(r.combinations.length,0)});
test('configurator network error never means impossible assembly',async()=>{const r=await resolveGearMotor(input,async()=>{throw Error('offline')},invoke);assert.equal(r.selection_complete,false);assert(r.notice.includes('не означает несовместимость'))});
test('exact search precedes tolerance; returned RPM stays real',async()=>{let n=0;const r=await resolveGearMotor({...input,output_rpm:55},async()=>Response.json(++n===1?[]:rows),invoke);assert.equal(n,2);assert.equal(r.match_kind,'within_15_percent');assert.equal(r.combinations[0].output_rpm,54)});
test('configurator alternatives separated by slashes are resolved as individual reducer articles',async()=>{
 const aliasRows=rows.map(row=>({...row,buhta_gear:'99.99.99.999999/'+row.buhta_gear.trim()}));
 const result=await resolveGearMotor({...input,ratio:25,pam:'80B5'},async()=>Response.json(aliasRows),invoke);
 assert.equal(result.combinations[0].reducer.article,'07.01.01.000074');
 assert.equal(result.combinations[0].ratio,25);
 const mismatched=await resolveGearMotor({...input,ratio:30,pam:'80B5'},async()=>Response.json(aliasRows),invoke);
 assert.equal(mismatched.combinations.length,0);
});
test('a motor missing from the article index is verified by model and exact live article',async()=>{
 const reducer={url:'https://www.elcomspb.ru/retail/gearbox/wormgears/wgitem/07.01.01.000007-reduktor-nmrw040-5-71b5/',article:'07.01.01.000007',attributes:{'Присоединительный размер к электродвигателю (РАМ)':'71B5','Значение передаточного отношения':'5'}};
 const motor={url:'https://www.elcomspb.ru/retail/electric_engines/general-purpose_engines/5ai/5ai-63-b4-im3081/',article:'01.01.213712',title:'Эл.двигатель 5АИ 63 В4 0.37/1500 IM 3081',attributes:{'Мощность (кВт)':'0,37','Монтажное исполнение':'3081'}};
 const row={id:74741,gab:'040',peredat:'5',pam_name:'71B5',power_engine:'0.37',gearbox_ratio:'264',to_engine_name:'5АИ 63 В4 3081',buhta_gear:reducer.article,buhta_engine:motor.article};
 const params={frame:40,power_kw:0.37,output_rpm:264,mount:'B5',motor_mount:'3081',pam:'71B5',ratio:5};
 const lookup=async()=>Response.json([row]);
 const cards=article=>async(_name,{urls})=>urls.map(url=>url===reducer.url?reducer:url===motor.url?{...motor,article}:{url,error:'fixture not found'});
 const result=await resolveGearMotor(params,lookup,cards(motor.article));
 assert.equal(result.combinations[0].motor.article,motor.article);
 const mismatch=await resolveGearMotor(params,lookup,cards('01.01.213531'));
 assert.equal(mismatch.combinations.length,0);
});
test('RC uses its own configurator filter and verifies the requested gearbox variant',async()=>{
 const reducer={url:'https://www.elcomspb.ru/retail/gearbox/cylindrical/gear-rc/reduktor-rc02-54-71b5-b02/',article:'07.01.03.000210',title:'Редуктор RC02-54/71B5 (B02)',attributes:{'Присоединительный размер к электродвигателю (РАМ)':'71B5','Значение передаточного отношения':'54'}};
 const motor={url:'https://www.elcomspb.ru/retail/electric_engines/general-purpose_engines/5ai/5ai-63-b4-im3081/',article:'01.01.213712',title:'Эл.двигатель 5АИ 63 В4 0.37/1500 IM 3081',attributes:{'Мощность (кВт)':'0,37','Монтажное исполнение':'3081'}};
 const row={id:119195,gab:'02',peredat:'54',pam_name:'71B5',power_engine:'0.37',gearbox_ratio:'24.4',to_engine_name:'5АИ 63 В4 3081',buhta_gear:reducer.article,buhta_engine:motor.article};
 const params={family:'RC',variant:'B02',frame:2,power_kw:0.37,output_rpm:24.4,mount:'B5',motor_mount:'3081',pam:'71B5',ratio:54,reducer_query:'RC02-54/71B5'};
 const query=async(_url,{body})=>{assert.equal(body.get('filter_model_gear'),'3');assert.equal(body.get('new_ggearval_rc'),'02');return Response.json([row])};
 const cards=async(_name,{urls})=>[reducer,motor].filter(c=>urls.includes(c.url));
 const result=await resolveGearMotor(params,query,cards);
 assert.equal(result.combinations[0].configurator_row_id,119195);
 const mismatch=await resolveGearMotor({...params,variant:'B01'},query,cards);
 assert.equal(mismatch.combinations.length,0);
});
test('DRW keeps requested and configurator speeds separate and confirms only the motor article',async()=>{
 const row={id:1923,gab:'040/063',peredat:'100',first_peredat:'10',second_peredat:'10',power_engine:'0.37',to_engine_name:'5АИ 63 В4 3081',pam_name:'71B5',real_ratio_engine:'1320',gearbox_ratio:13.2,flange:'прямая стыковка'};
 const motor={article:'01.01.213712',title:'Эл.двигатель 5АИ 63 В4 0.37/1500 IM 3081',attributes:{'Мощность (кВт)':'0,37','Монтажное исполнение':'3081'},stock:{Питер:70}};
 const result=await resolveDoubleWorm('040/063',100,0.37,1400,'3081',async(_url,{body})=>{
  assert.equal(body.get('new_ggearval_drw'),'040/063');
  assert.equal(body.get('filter_model_gear'),'6');
  return Response.json([row,{...row,id:1924,flange:'переходная втулка'}]);
 },async(name,args)=>{
  assert.equal(name,'select_motor');assert.equal(args.mount,'3081');
  return {verified_components:[motor]};
 });
 const text=renderDoubleWorm(result.drw);
 for(const expected of ['10 × 10','14 об/мин','13,2 об/мин','1923','1924','| Редуктор | DRW 040/063, i = 100 | не подтверждён |','| 01.01.213712 | 70 |'])assert.ok(text.includes(expected),expected);
});
